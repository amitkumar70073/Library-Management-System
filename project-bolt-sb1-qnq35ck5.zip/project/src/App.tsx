import { useState } from 'react';
import { Route, Routes, Navigate } from 'react-router-dom';
import { Book } from 'lucide-react';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import Reports from './pages/Reports';
import Transactions from './pages/Transactions';
import Maintenance from './pages/Maintenance';
import ProtectedRoute from './components/ProtectedRoute';
import AdminRoute from './components/AdminRoute';
import './App.css';

function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route 
            path="/" 
            element={
              <ProtectedRoute>
                <div className="flex flex-col min-h-screen">
                  <Navbar />
                  <div className="flex-grow container mx-auto px-4 py-8">
                    <Dashboard />
                  </div>
                </div>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/dashboard" 
            element={
              <ProtectedRoute>
                <div className="flex flex-col min-h-screen">
                  <Navbar />
                  <div className="flex-grow container mx-auto px-4 py-8">
                    <Dashboard />
                  </div>
                </div>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/reports" 
            element={
              <ProtectedRoute>
                <div className="flex flex-col min-h-screen">
                  <Navbar />
                  <div className="flex-grow container mx-auto px-4 py-8">
                    <Reports />
                  </div>
                </div>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/transactions" 
            element={
              <ProtectedRoute>
                <div className="flex flex-col min-h-screen">
                  <Navbar />
                  <div className="flex-grow container mx-auto px-4 py-8">
                    <Transactions />
                  </div>
                </div>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/maintenance" 
            element={
              <AdminRoute>
                <div className="flex flex-col min-h-screen">
                  <Navbar />
                  <div className="flex-grow container mx-auto px-4 py-8">
                    <Maintenance />
                  </div>
                </div>
              </AdminRoute>
            } 
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </AuthProvider>
  );
}

export default App;