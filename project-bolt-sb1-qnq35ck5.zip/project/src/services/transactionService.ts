import { Transaction, NewTransaction } from '../types/transaction';

// Mock data for transactions
const MOCK_TRANSACTIONS: Transaction[] = [
  {
    id: 'TRX001',
    membershipId: 'MEM001',
    memberName: 'John Doe',
    type: 'borrow',
    details: 'Borrowed "The Great Gatsby" by F. Scott Fitzgerald',
    date: '2025-01-10T14:30:00Z',
    status: 'completed'
  },
  {
    id: 'TRX002',
    membershipId: 'MEM002',
    memberName: 'Jane Smith',
    type: 'borrow',
    details: 'Borrowed "To Kill a Mockingbird" by Harper Lee',
    date: '2025-01-12T10:15:00Z',
    status: 'completed'
  },
  {
    id: 'TRX003',
    membershipId: 'MEM001',
    memberName: 'John Doe',
    type: 'return',
    details: 'Returned "The Great Gatsby" by F. Scott Fitzgerald',
    date: '2025-01-15T16:45:00Z',
    status: 'completed'
  },
  {
    id: 'TRX004',
    membershipId: 'MEM003',
    memberName: 'Robert Johnson',
    type: 'payment',
    details: 'Paid late fee of $5.00',
    date: '2025-01-08T11:20:00Z',
    status: 'completed'
  },
  {
    id: 'TRX005',
    membershipId: 'MEM004',
    memberName: 'Emily Williams',
    type: 'borrow',
    details: 'Borrowed "1984" by George Orwell',
    date: '2025-01-16T09:30:00Z',
    status: 'pending'
  }
];

// Get all transactions
export const getTransactions = async (): Promise<Transaction[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  return [...MOCK_TRANSACTIONS];
};

// Get transaction by ID
export const getTransactionById = async (id: string): Promise<Transaction | null> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  return MOCK_TRANSACTIONS.find(transaction => transaction.id === id) || null;
};

// Get transactions by membership ID
export const getTransactionsByMembershipId = async (membershipId: string): Promise<Transaction[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  return MOCK_TRANSACTIONS.filter(transaction => transaction.membershipId === membershipId);
};

// Add new transaction
export const addTransaction = async (newTransaction: NewTransaction): Promise<Transaction> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const transaction: Transaction = {
    id: `TRX${Math.floor(1000 + Math.random() * 9000)}`,
    ...newTransaction
  };
  
  // In a real application, this would save to a database
  MOCK_TRANSACTIONS.push(transaction);
  
  return transaction;
};

// Update transaction
export const updateTransaction = async (id: string, updates: Partial<Transaction>): Promise<Transaction> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const index = MOCK_TRANSACTIONS.findIndex(transaction => transaction.id === id);
  if (index === -1) {
    throw new Error('Transaction not found');
  }
  
  const updatedTransaction = {
    ...MOCK_TRANSACTIONS[index],
    ...updates
  };
  
  MOCK_TRANSACTIONS[index] = updatedTransaction;
  
  return updatedTransaction;
};