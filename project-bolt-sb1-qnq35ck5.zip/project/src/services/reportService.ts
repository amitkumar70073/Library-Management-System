import { Report } from '../types/report';

// Mock data for reports
const MOCK_REPORTS: Report[] = [
  {
    id: 'RPT001',
    title: 'Monthly Membership Report',
    description: 'Summary of all membership activities for January 2025',
    generated: '2025-01-31T23:59:59Z',
    type: 'membership'
  },
  {
    id: 'RPT002',
    title: 'Quarterly Transaction Report',
    description: 'Detailed breakdown of all library transactions for Q1 2025',
    generated: '2025-03-31T23:59:59Z',
    type: 'transaction'
  },
  {
    id: 'RPT003',
    title: 'Annual Inventory Report',
    description: 'Complete inventory of all library materials as of December 2024',
    generated: '2024-12-31T23:59:59Z',
    type: 'inventory'
  },
  {
    id: 'RPT004',
    title: 'Overdue Items Report',
    description: 'List of all overdue books and materials as of January 15, 2025',
    generated: '2025-01-15T23:59:59Z',
    type: 'transaction'
  },
  {
    id: 'RPT005',
    title: 'New Acquisitions Report',
    description: 'List of all new books and materials added in January 2025',
    generated: '2025-01-31T23:59:59Z',
    type: 'inventory'
  }
];

// Get all reports
export const getReports = async (): Promise<Report[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  return [...MOCK_REPORTS];
};

// Get report by ID
export const getReportById = async (id: string): Promise<Report | null> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  return MOCK_REPORTS.find(report => report.id === id) || null;
};

// Get reports by type
export const getReportsByType = async (type: string): Promise<Report[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  return MOCK_REPORTS.filter(report => report.type === type);
};

// Generate new report
export const generateReport = async (
  title: string,
  description: string,
  type: 'membership' | 'transaction' | 'inventory'
): Promise<Report> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  const report: Report = {
    id: `RPT${Math.floor(1000 + Math.random() * 9000)}`,
    title,
    description,
    generated: new Date().toISOString(),
    type
  };
  
  // In a real application, this would save to a database
  MOCK_REPORTS.push(report);
  
  return report;
};