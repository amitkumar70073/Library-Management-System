import { Membership, NewMembership } from '../types/membership';

// Mock data for memberships
const MOCK_MEMBERSHIPS: Membership[] = [
  {
    id: 'MEM001',
    name: 'John Doe',
    email: 'john.doe@example.com',
    phone: '555-123-4567',
    startDate: '2025-01-01',
    endDate: '2025-07-01', // 6 months
    isActive: true,
    duration: 6
  },
  {
    id: 'MEM002',
    name: 'Jane Smith',
    email: 'jane.smith@example.com',
    phone: '555-987-6543',
    startDate: '2024-11-15',
    endDate: '2025-11-15', // 1 year
    isActive: true,
    duration: 12
  },
  {
    id: 'MEM003',
    name: 'Robert Johnson',
    email: 'robert.johnson@example.com',
    phone: '555-456-7890',
    startDate: '2024-06-10',
    endDate: '2024-12-10', // 6 months
    isActive: false,
    duration: 6
  },
  {
    id: 'MEM004',
    name: 'Emily Williams',
    email: 'emily.williams@example.com',
    phone: '555-789-0123',
    startDate: '2025-01-05',
    endDate: '2027-01-05', // 2 years
    isActive: true,
    duration: 24
  }
];

// Get all memberships
export const getMemberships = async (): Promise<Membership[]> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  return [...MOCK_MEMBERSHIPS];
};

// Get membership by ID
export const getMembershipById = async (id: string): Promise<Membership | null> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 500));
  return MOCK_MEMBERSHIPS.find(membership => membership.id === id) || null;
};

// Add new membership
export const addMembership = async (newMembership: NewMembership): Promise<Membership> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const startDate = new Date().toISOString().split('T')[0];
  const endDate = new Date(
    new Date().setMonth(new Date().getMonth() + newMembership.duration)
  ).toISOString().split('T')[0];
  
  const membership: Membership = {
    id: `MEM${Math.floor(1000 + Math.random() * 9000)}`,
    name: newMembership.name,
    email: newMembership.email,
    phone: newMembership.phone,
    startDate,
    endDate,
    isActive: true,
    duration: newMembership.duration
  };
  
  // In a real application, this would save to a database
  MOCK_MEMBERSHIPS.push(membership);
  
  return membership;
};

// Update membership
export const updateMembership = async (id: string, updates: Partial<Membership>): Promise<Membership> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const index = MOCK_MEMBERSHIPS.findIndex(membership => membership.id === id);
  if (index === -1) {
    throw new Error('Membership not found');
  }
  
  const updatedMembership = {
    ...MOCK_MEMBERSHIPS[index],
    ...updates
  };
  
  MOCK_MEMBERSHIPS[index] = updatedMembership;
  
  return updatedMembership;
};

// Cancel membership
export const cancelMembership = async (id: string): Promise<void> => {
  // Simulate API call
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const index = MOCK_MEMBERSHIPS.findIndex(membership => membership.id === id);
  if (index === -1) {
    throw new Error('Membership not found');
  }
  
  MOCK_MEMBERSHIPS[index] = {
    ...MOCK_MEMBERSHIPS[index],
    isActive: false
  };
};