export interface Membership {
  id: string;
  name: string;
  email: string;
  phone: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  duration: number; // in months
}

export interface NewMembership {
  name: string;
  email: string;
  phone: string;
  duration: number; // in months
}