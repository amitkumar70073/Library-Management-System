export interface Transaction {
  id: string;
  membershipId: string;
  memberName: string;
  type: 'borrow' | 'return' | 'payment' | 'other';
  details: string;
  date: string;
  status: 'pending' | 'completed' | 'canceled';
}

export interface NewTransaction {
  membershipId: string;
  memberName: string;
  type: 'borrow' | 'return' | 'payment' | 'other';
  details: string;
  date: string;
  status: 'pending' | 'completed' | 'canceled';
}