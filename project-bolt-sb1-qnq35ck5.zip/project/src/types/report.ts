export interface Report {
  id: string;
  title: string;
  description: string;
  generated: string; // ISO date string
  type: 'membership' | 'transaction' | 'inventory';
}