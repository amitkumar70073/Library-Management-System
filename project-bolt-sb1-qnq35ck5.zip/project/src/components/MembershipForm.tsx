import { useState } from 'react';
import Button from './Button';
import Input from './Input';
import RadioGroup from './RadioGroup';
import { addMembership } from '../services/membershipService';

interface MembershipFormProps {
  onSuccess: () => void;
  onCancel: () => void;
  memberId?: string;
}

export const MembershipForm: React.FC<MembershipFormProps> = ({ 
  onSuccess, 
  onCancel, 
  memberId 
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [duration, setDuration] = useState('6');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Form validation
    if (!name || !email || !phone) {
      setError('Please fill in all required fields');
      return;
    }
    
    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      return;
    }
    
    try {
      setLoading(true);
      await addMembership({
        name,
        email,
        phone,
        duration: parseInt(duration),
      });
      onSuccess();
    } catch (err) {
      console.error(err);
      setError('Failed to create membership');
    } finally {
      setLoading(false);
    }
  };

  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  return (
    <form onSubmit={handleSubmit}>
      {error && (
        <div className="bg-red-50 text-red-800 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      <Input
        id="name"
        label="Full Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      
      <Input
        id="email"
        label="Email address"
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      
      <Input
        id="phone"
        label="Phone Number"
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
        required
      />
      
      <RadioGroup
        label="Membership Duration"
        name="duration"
        options={[
          { label: '6 Months', value: '6' },
          { label: '1 Year', value: '12' },
          { label: '2 Years', value: '24' }
        ]}
        value={duration}
        onChange={setDuration}
      />
      
      <div className="flex justify-end space-x-3 mt-6">
        <Button
          type="button"
          variant="secondary"
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          loading={loading}
        >
          {memberId ? 'Update' : 'Add'} Membership
        </Button>
      </div>
    </form>
  );
};