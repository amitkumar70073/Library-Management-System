import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Book, Menu, X, BarChart, FileText, Settings, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Navbar: React.FC = () => {
  const { user, logout, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="bg-blue-800 text-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Book className="h-8 w-8 mr-2" />
            <span className="font-bold text-xl">Library Management</span>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/dashboard" className="hover:text-blue-200 transition-colors">Dashboard</Link>
            <Link to="/reports" className="hover:text-blue-200 transition-colors">Reports</Link>
            <Link to="/transactions" className="hover:text-blue-200 transition-colors">Transactions</Link>
            {isAdmin() && (
              <Link to="/maintenance" className="hover:text-blue-200 transition-colors">Maintenance</Link>
            )}
            <div className="relative ml-4 group">
              <button className="flex items-center space-x-1 focus:outline-none">
                <span>{user?.name}</span>
              </button>
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                <button 
                  onClick={handleLogout}
                  className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                >
                  Logout
                </button>
              </div>
            </div>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button onClick={toggleMenu} className="focus:outline-none">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-blue-700 py-4 px-4 fade-in">
          <div className="flex flex-col space-y-4">
            <Link 
              to="/dashboard" 
              className="flex items-center space-x-2 hover:text-blue-200"
              onClick={() => setIsMenuOpen(false)}
            >
              <BarChart size={20} />
              <span>Dashboard</span>
            </Link>
            <Link 
              to="/reports" 
              className="flex items-center space-x-2 hover:text-blue-200"
              onClick={() => setIsMenuOpen(false)}
            >
              <FileText size={20} />
              <span>Reports</span>
            </Link>
            <Link 
              to="/transactions" 
              className="flex items-center space-x-2 hover:text-blue-200"
              onClick={() => setIsMenuOpen(false)}
            >
              <FileText size={20} />
              <span>Transactions</span>
            </Link>
            {isAdmin() && (
              <Link 
                to="/maintenance" 
                className="flex items-center space-x-2 hover:text-blue-200"
                onClick={() => setIsMenuOpen(false)}
              >
                <Settings size={20} />
                <span>Maintenance</span>
              </Link>
            )}
            <hr className="border-blue-600" />
            <button 
              onClick={() => {
                handleLogout();
                setIsMenuOpen(false);
              }}
              className="flex items-center space-x-2 text-left text-red-300 hover:text-red-200"
            >
              <LogOut size={20} />
              <span>Logout</span>
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;