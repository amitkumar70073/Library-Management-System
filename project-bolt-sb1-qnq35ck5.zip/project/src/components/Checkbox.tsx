import React from 'react';

interface CheckboxProps {
  id: string;
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  error?: string;
  disabled?: boolean;
  className?: string;
}

const Checkbox: React.FC<CheckboxProps> = ({
  id,
  label,
  checked,
  onChange,
  error,
  disabled = false,
  className = '',
}) => {
  return (
    <div className={`mb-4 ${className}`}>
      <div className="flex items-center">
        <input
          id={id}
          type="checkbox"
          checked={checked}
          onChange={(e) => onChange(e.target.checked)}
          disabled={disabled}
          className={`
            h-4 w-4 rounded
            text-blue-600 focus:ring-blue-500 border-gray-300
            ${disabled ? 'opacity-60 cursor-not-allowed' : ''}
          `}
        />
        <label
          htmlFor={id}
          className={`ml-2 block text-sm text-gray-700 ${disabled ? 'opacity-60' : ''}`}
        >
          {label}
        </label>
      </div>
      {error && (
        <p className="mt-1 text-sm text-red-600">{error}</p>
      )}
    </div>
  );
};

export default Checkbox;