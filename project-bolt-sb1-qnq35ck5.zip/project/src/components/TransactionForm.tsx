import { useState, useEffect } from 'react';
import Button from './Button';
import Input from './Input';
import RadioGroup from './RadioGroup';
import { addTransaction } from '../services/transactionService';
import { getMemberships } from '../services/membershipService';
import { Membership } from '../types/membership';

interface TransactionFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export const TransactionForm: React.FC<TransactionFormProps> = ({ 
  onSuccess, 
  onCancel
}) => {
  const [membershipId, setMembershipId] = useState('');
  const [details, setDetails] = useState('');
  const [type, setType] = useState('borrow');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [selectedMember, setSelectedMember] = useState<Membership | null>(null);

  useEffect(() => {
    getMemberships().then(data => {
      setMemberships(data);
    });
  }, []);

  const handleMembershipIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const id = e.target.value;
    setMembershipId(id);
    
    // Find the member with matching ID
    const member = memberships.find(m => m.id === id);
    setSelectedMember(member || null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Form validation
    if (!membershipId || !details || !type) {
      setError('Please fill in all required fields');
      return;
    }
    
    if (!selectedMember) {
      setError('Invalid membership ID');
      return;
    }
    
    try {
      setLoading(true);
      await addTransaction({
        membershipId,
        memberName: selectedMember.name,
        type,
        details,
        date: new Date().toISOString(),
        status: 'completed'
      });
      onSuccess();
    } catch (err) {
      console.error(err);
      setError('Failed to create transaction');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {error && (
        <div className="bg-red-50 text-red-800 p-3 rounded-md mb-4">
          {error}
        </div>
      )}
      
      <Input
        id="membershipId"
        label="Membership ID"
        value={membershipId}
        onChange={handleMembershipIdChange}
        required
      />
      
      {selectedMember && (
        <div className="mb-4 p-3 bg-blue-50 rounded-md">
          <p className="text-sm font-medium text-gray-700">Member Information:</p>
          <p className="text-sm text-gray-600">{selectedMember.name}</p>
          <p className="text-sm text-gray-600">{selectedMember.email}</p>
          <p className="text-sm text-gray-600 mt-1">
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
              selectedMember.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              {selectedMember.isActive ? 'Active' : 'Inactive'}
            </span>
          </p>
        </div>
      )}
      
      <RadioGroup
        label="Transaction Type"
        name="transactionType"
        options={[
          { label: 'Borrow', value: 'borrow' },
          { label: 'Return', value: 'return' },
          { label: 'Payment', value: 'payment' },
          { label: 'Other', value: 'other' }
        ]}
        value={type}
        onChange={setType}
      />
      
      <Input
        id="details"
        label="Transaction Details"
        value={details}
        onChange={(e) => setDetails(e.target.value)}
        required
      />
      
      <div className="flex justify-end space-x-3 mt-6">
        <Button
          type="button"
          variant="secondary"
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          loading={loading}
        >
          Create Transaction
        </Button>
      </div>
    </form>
  );
};