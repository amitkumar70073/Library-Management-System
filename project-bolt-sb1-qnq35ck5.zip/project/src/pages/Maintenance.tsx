import { useState, useEffect } from 'react';
import { Settings, Database, Library, Users } from 'lucide-react';
import Card from '../components/Card';
import Button from '../components/Button';
import { useAuth } from '../context/AuthContext';

const MaintenanceCard = ({ 
  title, 
  description, 
  icon: Icon, 
  buttonText, 
  onClick, 
  bgColor = 'bg-blue-50',
  iconColor = 'text-blue-600'
}: {
  title: string;
  description: string;
  icon: typeof Settings;
  buttonText: string;
  onClick: () => void;
  bgColor?: string;
  iconColor?: string;
}) => (
  <Card className="hover:shadow-lg transition-shadow duration-300">
    <div className="flex items-start">
      <div className={`p-4 rounded-lg ${bgColor} ${iconColor} mr-4`}>
        <Icon size={24} />
      </div>
      <div className="flex-1">
        <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
        <p className="text-gray-600 mt-1 mb-4">{description}</p>
        <Button onClick={onClick} className="w-full sm:w-auto">
          {buttonText}
        </Button>
      </div>
    </div>
  </Card>
);

const Maintenance = () => {
  const { isAdmin } = useAuth();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, []);

  // Redirect if not admin (additional security)
  useEffect(() => {
    if (!loading && !isAdmin()) {
      window.location.href = '/dashboard';
    }
  }, [loading, isAdmin]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-800"></div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Maintenance</h1>
        <p className="text-gray-600">Manage library settings and data</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <MaintenanceCard 
          title="Database Backup"
          description="Create a backup of the entire library database, including all member records, transactions, and book inventory."
          icon={Database}
          buttonText="Create Backup"
          onClick={() => alert('Database backup started')}
          bgColor="bg-blue-50"
          iconColor="text-blue-600"
        />
        
        <MaintenanceCard 
          title="Book Catalog"
          description="Manage the library's book catalog. Add new books, update existing records, or remove outdated entries."
          icon={Library}
          buttonText="Manage Catalog"
          onClick={() => alert('Book catalog opened')}
          bgColor="bg-green-50"
          iconColor="text-green-600"
        />
        
        <MaintenanceCard 
          title="Member Records"
          description="View and manage all member records. Update personal information, membership status, or payment history."
          icon={Users}
          buttonText="View Records"
          onClick={() => alert('Member records opened')}
          bgColor="bg-purple-50"
          iconColor="text-purple-600"
        />
        
        <MaintenanceCard 
          title="System Settings"
          description="Configure system-wide settings for the library management system including notifications and defaults."
          icon={Settings}
          buttonText="Configure"
          onClick={() => alert('System settings opened')}
          bgColor="bg-amber-50"
          iconColor="text-amber-600"
        />
      </div>

      <Card title="Maintenance Logs">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date & Time
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  User
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Activity
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  2025-01-15 14:32:10
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  Admin User
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  System backup
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    Completed
                  </span>
                </td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  2025-01-14 09:15:23
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  Admin User
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  Added 25 new books to catalog
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    Completed
                  </span>
                </td>
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  2025-01-13 16:45:07
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  Admin User
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  Updated system settings
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    Completed
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default Maintenance;