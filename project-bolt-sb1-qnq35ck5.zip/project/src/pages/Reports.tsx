import { useState, useEffect } from 'react';
import { FileText, Download, Filter } from 'lucide-react';
import Card from '../components/Card';
import Button from '../components/Button';
import { getReports } from '../services/reportService';
import { Report } from '../types/report';

const Reports = () => {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    const loadReports = async () => {
      try {
        const reportData = await getReports();
        setReports(reportData);
      } catch (error) {
        console.error('Error loading reports:', error);
      } finally {
        setLoading(false);
      }
    };

    loadReports();
  }, []);

  const filteredReports = filter === 'all' 
    ? reports 
    : reports.filter(report => report.type === filter);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-800"></div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Reports</h1>
          <p className="text-gray-600">View and download library reports</p>
        </div>
      </div>

      <Card className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="flex items-center space-x-4">
            <span className="text-gray-700">Filter by:</span>
            <div className="relative">
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="block appearance-none bg-white border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-blue-500"
              >
                <option value="all">All Reports</option>
                <option value="membership">Membership</option>
                <option value="transaction">Transaction</option>
                <option value="inventory">Inventory</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                  <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                </svg>
              </div>
            </div>
          </div>
          
          <Button 
            variant="secondary"
            className="flex items-center justify-center"
          >
            <Download size={16} className="mr-2" />
            Export All
          </Button>
        </div>
      </Card>

      {filteredReports.length > 0 ? (
        <div className="grid grid-cols-1 gap-6">
          {filteredReports.map((report) => (
            <Card key={report.id} className="overflow-hidden">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                <div className="flex items-start space-x-4">
                  <div className={`p-3 rounded-lg 
                    ${report.type === 'membership' ? 'bg-blue-100 text-blue-800' : 
                      report.type === 'transaction' ? 'bg-green-100 text-green-800' : 
                      'bg-amber-100 text-amber-800'}`}>
                    <FileText size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">{report.title}</h3>
                    <p className="text-gray-600">{report.description}</p>
                    <div className="mt-2 flex items-center space-x-4">
                      <span className="text-sm text-gray-500">Generated: {new Date(report.generated).toLocaleDateString()}</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium 
                        ${report.type === 'membership' ? 'bg-blue-100 text-blue-800' : 
                          report.type === 'transaction' ? 'bg-green-100 text-green-800' : 
                          'bg-amber-100 text-amber-800'}`}>
                        {report.type.charAt(0).toUpperCase() + report.type.slice(1)}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 lg:mt-0 flex space-x-2">
                  <Button 
                    variant="secondary"
                    className="flex items-center"
                  >
                    <Download size={16} className="mr-1" />
                    Download
                  </Button>
                  <Button className="flex items-center">
                    View
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <div className="text-center py-8">
            <FileText size={48} className="mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900">No reports found</h3>
            <p className="mt-1 text-gray-500">
              {filter !== 'all' 
                ? `No ${filter} reports are available at this time.` 
                : 'No reports are available at this time.'}
            </p>
          </div>
        </Card>
      )}
    </div>
  );
};

export default Reports;