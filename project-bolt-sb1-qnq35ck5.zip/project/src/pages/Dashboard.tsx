import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle, UserPlus, RefreshCw, BookOpen, Users, FileText } from 'lucide-react';
import Card from '../components/Card';
import Button from '../components/Button';
import { useAuth } from '../context/AuthContext';
import { MembershipForm } from '../components/MembershipForm';
import { getMemberships } from '../services/membershipService';
import { Membership } from '../types/membership';

const Dashboard = () => {
  const navigate = useNavigate();
  const { user, isAdmin } = useAuth();
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [totalMembers, setTotalMembers] = useState(0);
  const [activeMembers, setActiveMembers] = useState(0);
  const [showAddMembershipForm, setShowAddMembershipForm] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        const membershipData = await getMemberships();
        setMemberships(membershipData);
        setTotalMembers(membershipData.length);
        setActiveMembers(membershipData.filter(m => m.isActive).length);
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadDashboardData();
  }, []);

  const handleAddMembership = () => {
    setShowAddMembershipForm(true);
  };

  const handleMembershipAdded = () => {
    setShowAddMembershipForm(false);
    // Refresh data
    getMemberships().then(data => {
      setMemberships(data);
      setTotalMembers(data.length);
      setActiveMembers(data.filter(m => m.isActive).length);
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-800"></div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
        <p className="text-gray-600">Welcome back, {user?.name}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-blue-800 to-blue-700 text-white">
          <div className="flex items-center">
            <div className="bg-blue-900 bg-opacity-50 p-3 rounded-lg mr-4">
              <Users size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Total Members</h3>
              <p className="text-3xl font-bold">{totalMembers}</p>
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-green-600 to-green-500 text-white">
          <div className="flex items-center">
            <div className="bg-green-700 bg-opacity-50 p-3 rounded-lg mr-4">
              <UserPlus size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Active Members</h3>
              <p className="text-3xl font-bold">{activeMembers}</p>
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500 to-amber-400 text-white">
          <div className="flex items-center">
            <div className="bg-amber-600 bg-opacity-50 p-3 rounded-lg mr-4">
              <BookOpen size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Books Available</h3>
              <p className="text-3xl font-bold">125</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card title="Quick Actions">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Button 
              onClick={handleAddMembership} 
              className="flex items-center justify-center"
            >
              <UserPlus size={18} className="mr-2" />
              Add Membership
            </Button>
            
            <Button 
              onClick={() => navigate('/transactions')}
              className="flex items-center justify-center"
              variant="secondary"
            >
              <FileText size={18} className="mr-2" />
              New Transaction
            </Button>
            
            {isAdmin() && (
              <Button 
                onClick={() => navigate('/maintenance')}
                className="flex items-center justify-center"
                variant="secondary"
              >
                <RefreshCw size={18} className="mr-2" />
                Maintenance
              </Button>
            )}
            
            <Button 
              onClick={() => navigate('/reports')}
              className="flex items-center justify-center" 
              variant="secondary"
            >
              <FileText size={18} className="mr-2" />
              View Reports
            </Button>
          </div>
        </Card>

        <Card title="Recent Memberships">
          {memberships.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Name
                    </th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Member ID
                    </th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {memberships.slice(0, 5).map((membership) => (
                    <tr key={membership.id} className="hover:bg-gray-50">
                      <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-800">
                        {membership.name}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-600">
                        {membership.id}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          membership.isActive 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {membership.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-4 text-gray-500">
              No memberships found
            </div>
          )}
          
          {memberships.length > 5 && (
            <div className="mt-4 text-right">
              <Button 
                variant="secondary" 
                onClick={() => navigate('/transactions')}
              >
                View All
              </Button>
            </div>
          )}
        </Card>
      </div>

      {showAddMembershipForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-800">Add New Membership</h2>
                <button 
                  onClick={() => setShowAddMembershipForm(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <MembershipForm onSuccess={handleMembershipAdded} onCancel={() => setShowAddMembershipForm(false)} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;